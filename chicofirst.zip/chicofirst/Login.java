package com.example.chicofirst;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.database.Cursor;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Objects;
public class Login extends AppCompatActivity {
        DatabaseHelper myDB;
        EditText editName,editPassword;
        Button btnLoginData;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        myDB = new DatabaseHelper(this);
        btnLoginData = findViewById(R.id.btnLogin);
        editName = findViewById(R.id.editTextUserName);
        editPassword = findViewById(R.id.editTextPassword);
        loginData();
        final Button btnReset = (Button) findViewById(R.id.btnReset);
        btnReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), Reset.class);
                startActivity(i);
            }
        });
        final Button btnRegister = (Button) findViewById(R.id.btnRegister);
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), Register.class);
                startActivity(i);
            }
        });
        final Button btnDeliveryMan = (Button) findViewById(R.id.btnDeliveryMan);
        btnDeliveryMan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), DeliveryDetails.class);
                startActivity(i);
            }
        });
    }
    public void loginData(){
        btnLoginData.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                try {
                    String userName = editName.getText().toString();
                    String password = editPassword.getText().toString();
                    Cursor results = myDB.getLoginData(userName);
                    if (userName.isEmpty() || password.isEmpty()) {
                        Toast.makeText(getApplicationContext(), "All input field are required !", Toast.LENGTH_SHORT).show();
                    }
                    if (results.getCount() == 0) {
                        Toast.makeText(getApplicationContext(), "Username or Password Incorrect", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    while (results.moveToNext()) {
                        String temp_userName = results.getString(0);
                        String temp_password = results.getString(1);
                        if (Objects.equals(temp_userName, userName) && Objects.equals(temp_password, password)) {
                            Toast.makeText(getApplicationContext(), "Login success", Toast.LENGTH_SHORT).show();
                            AppGlobal.userName = userName;
                            finish();
                            myDB.clearTableCurrentOrder();
                            Intent i = new Intent(getApplicationContext(), Menu.class);
                            startActivity(i);
                        }
                        else{
                                Toast.makeText(getApplicationContext(), "Username or Password Incorrect", Toast.LENGTH_SHORT).show();
                            }
                        }
                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}