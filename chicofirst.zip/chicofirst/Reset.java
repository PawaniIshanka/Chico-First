package com.example.chicofirst;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
public class Reset extends AppCompatActivity {
    DatabaseHelper myDB;
    EditText editName,editEmail,editPassword,editConfirmPassword;
    Button btnReset;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset);
        myDB = new DatabaseHelper(this);
        editName = findViewById(R.id.editTextUserName);
        editEmail = findViewById(R.id.editTextEmailAddress);
        editPassword = findViewById(R.id.editTextPassword);
        editConfirmPassword = findViewById(R.id.editTextRePassword);
        btnReset = findViewById(R.id.btnReset);
        btnReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resetData(editName.getText().toString());
            }
        });
    }
    public void resetData(String username) {
        Cursor result = myDB.getUserData(username);
        String password = editPassword.getText().toString();
        String rePassword = editConfirmPassword.getText().toString();
        String email = editEmail.getText().toString();
        if (username.isEmpty() || email.isEmpty() || password.isEmpty() || rePassword.isEmpty()) {
            Toast.makeText(this, "All fields are required !", Toast.LENGTH_SHORT).show();
        }
        else {
            if (password.equals(rePassword)) {
                String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
                if (email.matches(emailPattern)) {
                    if (result.getCount() == 0)
                    {
                        Toast.makeText(this, "Username doesnot exits on the database", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        while (result.moveToNext()) {
                            String tempEmail = result.getString(1);
                            if (tempEmail.equals(email)) {
                                boolean isPasswordUpdated = myDB.resetUserPassword(username, password);
                                if (isPasswordUpdated) {
                                    Toast.makeText(this, "Password Reset Successful. Your can use your new Password to Login", Toast.LENGTH_SHORT).show();
                                    finish();
                                    Intent i = new Intent(getApplicationContext(), Login.class);
                                    startActivity(i);
                                } else {
                                    Toast.makeText(this, "Password Update Unsuccessful", Toast.LENGTH_SHORT).show();
                                }
                            } else {
                                Toast.makeText(this, "Email your provided does not match with the email in database", Toast.LENGTH_SHORT).show();
                            }
                        }}}
                else{
                        Toast.makeText(this, "Email is not in valid format", Toast.LENGTH_SHORT).show();
                    }

                } else {
                    Toast.makeText(this, "Password and Re password must be same", Toast.LENGTH_SHORT).show();
                }
            }
        }
}