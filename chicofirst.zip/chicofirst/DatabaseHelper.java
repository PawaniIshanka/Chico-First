package com.example.chicofirst;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "ChicoFirst.db";
    public static final String TABLE_NAME = "register";
    public static final String COL_1 = "ID";
    public static final String COL_2 = "USERNAME";
    public static final String COL_3 = "EMAIL";
    public static final String COL_4 = "PASSWORD";

    public static final String TABLE_NAME1 = "current_orders";
    public static final String T1COL_01 = "ID";
    public static final String T1COL_02 = "FOODNAME";
    public static final String T1COL_03 = "AMOUNT";
    public static final String T1COL_04 = "QTY";
    public static final String T1COL_05 = "TOTAL";

    public static final String TABLE_NAME2 = "user_details";
    public static final String T2COL_01 = "ID";

    public static final String T2COL_02 = "USERNAME";
    public static final String T2COL_03 = "NAME";
    public static final String T2COL_04 = "ADDRESS";
    public static final String T2COL_05 = "TELEPHONE";





    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_NAME + "(ID INTEGER PRIMARY KEY AUTOINCREMENT, USERNAME TEXT,EMAIL TEXT,PASSWORD TEXT )");
        db.execSQL("CREATE TABLE " + TABLE_NAME1 + "(ID INTEGER PRIMARY KEY AUTOINCREMENT, FOODNAME TEXT, AMOUNT INTEGER, QTY INTEGER, TOTAL INTEGER)");
        db.execSQL("CREATE TABLE " + TABLE_NAME2 + "(ID INTEGER PRIMARY KEY AUTOINCREMENT, USERNAME TEXT, NAME TEXT, ADDRESS TEXT, TELEPHONE TEXT)");

    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME1);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME2);
        onCreate(db);

    }
    public boolean insertRegistrationData(String userName, String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_2, userName);
        contentValues.put(COL_3, email);
        contentValues.put(COL_4, password);

        long results = db.insert(TABLE_NAME, null, contentValues);
        if(results == -1)
            return false;
        else
            return true;
    }

    public  boolean checkUsername(String username) {

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor result = db.query(TABLE_NAME, new String[]{"USERNAME"}, "USERNAME = ?", new String[]{username}, null, null, null);

        if (result.getCount() != 0) {
            return  true;
        }
        else {
            return false;
        }
    }
    public boolean addItemtoOrder(String foodName, String foodPrice, String foodQTY, String totalCost) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(T1COL_02, foodName);
        contentValues.put(T1COL_03, foodPrice);
        contentValues.put(T1COL_04, foodQTY);
        contentValues.put(T1COL_05,totalCost);
        long results = db.insert(TABLE_NAME1, null, contentValues);
        if(results == -1)
            return false;
        else
            return true;
    }
    public Cursor checkoutOrder(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor results = db.rawQuery("select * from " + TABLE_NAME1, null);
        return results;
    }
    public Cursor getUserData(String username){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor result = db.query(TABLE_NAME, new String[]{"USERNAME","EMAIL"}, "USERNAME = ?", new String[]{username}, null, null, null);
        return  result;
    }
    public Cursor getPersonalData(String username){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor result = db.query(TABLE_NAME2, new String[]{"NAME, ADDRESS, TELEPHONE"}, "USERNAME = ?", new String[]{username}, null, null, null);
        return  result;
    }
    public boolean getRowCountOrders() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor results = db.rawQuery("select * from " + TABLE_NAME1, null);
        int count = 0;
        while (results.moveToNext()) {
            count += 1;
        }
        if(count == 0) {
            return true;
        }
        else {
            return false;
        }
    }
    public boolean resetUserPassword(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_4, password);
        String selection = "USERNAME = ?";
        String[] selectionArgs = {username};
// Perform the update query
        int rowsUpdated = db.update(TABLE_NAME, contentValues, selection, selectionArgs);
// Check the result
        if (rowsUpdated == 1) {
            return true;
        } else {
            return false;
        }
    }
    public boolean insertUserDetails(String username, String name, String address, String telephone) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(T2COL_02, username);
        contentValues.put(T2COL_03, name);
        contentValues.put(T2COL_04, address);
        contentValues.put(T2COL_05, telephone);
        long results = db.insert(TABLE_NAME2, null, contentValues);
        if(results == -1)
            return false;
        else
            return true;
    }
    public boolean updateUserDetails(String username, String name, String address, String telephone) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(T2COL_03, name);
        contentValues.put(T2COL_04, address);
        contentValues.put(T2COL_05, telephone);
        String selection = "USERNAME = ?";
        String[] selectionArgs = {username};
// Perform the update query
        int rowsUpdated = db.update(TABLE_NAME2, contentValues, selection, selectionArgs);
// Check the result
        if (rowsUpdated == 1) {
            return true;
        } else {
            return false;
        }
    }
    public void clearTableCurrentOrder() {

        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME1, null, null);
    }
    public boolean checkAddress(String username){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor result = db.query(TABLE_NAME2, new String[]{"ADDRESS"}, "USERNAME = ?", new String[]{username}, null, null, null);

        if(result.getCount() == 0) {
            return false;
        }
        else
            return  true;
    }
    public Cursor getAllData(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor results = db.rawQuery("select * from " + TABLE_NAME, null);
        return results;
    }
    public boolean updateData(String name, String address, String phone) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(T2COL_02, name);
        contentValues.put(T2COL_03, address);
        contentValues.put(T2COL_04, phone);

        db.update(TABLE_NAME2, contentValues, "id = ?", new String[] {name});
        return true;
    }
    public Cursor getLoginData(String id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor result = db.query(TABLE_NAME, new String[]{"USERNAME", "PASSWORD"}, "USERNAME = ?", new String[]{id}, null, null, null);
        return result;
    }
}
