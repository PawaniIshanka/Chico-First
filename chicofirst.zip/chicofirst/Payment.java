package com.example.chicofirst;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.database.Cursor;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Objects;
public class Payment extends AppCompatActivity {
    DatabaseHelper myDB;
    EditText editCardNumber,editName,editDate,editCvv;
    TextView totalAmount;
    Button btnPay;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);
        myDB = new DatabaseHelper(this);
        editCardNumber = findViewById(R.id.editTextCardNumber);
        totalAmount = findViewById(R.id.textViewTotalAmount);
        editName = findViewById(R.id.editTextPersonName);
        editDate = findViewById(R.id.editTextDate);
        editCvv = findViewById(R.id.editTextNumber3);
        totalAmount.setText( "RS."+String.valueOf(AppGlobal.TotalAmount)+"/=");
        btnPay = findViewById(R.id.btnPay);
        final Button btnPay = (Button) findViewById(R.id.btnPay);
        btnPay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cardPayment();
            }
        });
    }
    public void cardPayment() {
        String cardNumber = editCardNumber.getText().toString();
        String name = editName.getText().toString();
        String cvv = editCvv.getText().toString();
        if (cardNumber.isEmpty() || name.isEmpty() || cvv.isEmpty()) {
            Toast.makeText(this, "All Fields are Required !", Toast.LENGTH_SHORT).show();
        }
        else {
            boolean isAddressAvailable = myDB.checkAddress(AppGlobal.userName);
            if (isAddressAvailable) {
                Toast.makeText(this, "Thank you for your payment", Toast.LENGTH_SHORT).show();
                finish();
                myDB.clearTableCurrentOrder();
                Intent i = new Intent(getApplicationContext(), Menu.class);
                startActivity(i);
            }
            else {
                Toast.makeText(this, "Your Address not Added yet. Please Add Address Before Make Order", Toast.LENGTH_SHORT).show();
            }
        }
    }
}

