package com.example.chicofirst;

public class AppGlobal {

    public static String userName;
    public static int TotalAmount;
}
