package com.example.chicofirst;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
public class Bbq extends AppCompatActivity {
    DatabaseHelper myDB;
    EditText editTextquantity;
    TextView textFoodName,textPrice;
    Button btnOrder, btnFinalize;
    String foodName, price;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bbq);
        myDB = new DatabaseHelper(this);
        textFoodName = findViewById(R.id.textfoodNameBBQ);
        textPrice = findViewById(R.id.textPriceBBQ);
        editTextquantity = findViewById(R.id.editTextBBQQTY);
        btnOrder = findViewById(R.id.btnOrderBBQ);
        btnFinalize = findViewById(R.id.btnCheckoutBBQ);
        //Set information of food
        foodName = "BBQ";
        price = "RS.500/=";
        textFoodName.setText(foodName);
        textPrice.setText(price);
        final ImageView btnHome = (ImageView) findViewById(R.id.btnHome);
        final ImageView btnPay = (ImageView) findViewById(R.id.btnPay);
        final ImageView btnLocation = (ImageView) findViewById(R.id.btnLocation);
        final ImageView btnLeft = (ImageView) findViewById(R.id.btnleft);
        final ImageView btnRight = (ImageView) findViewById(R.id.btnRight);
        btnHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
                Intent i = new Intent(getApplicationContext(), Menu.class);
                startActivity(i);
            }
        });
        btnPay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
                Intent i = new Intent(getApplicationContext(), Payment.class);
                startActivity(i);
            }
        });
        btnLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
                Intent i = new Intent(getApplicationContext(), MapsActivity.class);
                startActivity(i);
            }
        });
        btnLeft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
                Intent i = new Intent(getApplicationContext(), Rice.class);
                startActivity(i);
            }
        });
        btnRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
                Intent i = new Intent(getApplicationContext(), SeaFood.class);
                startActivity(i);
            }
        });
        btnOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addToCart();
            }
        });
        btnFinalize.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean isOrderTableEmpty = myDB.getRowCountOrders();
                if(isOrderTableEmpty) {
                    Toast.makeText(Bbq.this, "No Item in Cart. Please Add item", Toast.LENGTH_SHORT).show();
                } else {
                    finish();
                    Intent i = new Intent(getApplicationContext(), OrderDetails.class);
                    startActivity(i);
                }
            }
        });
    }
    public void addToCart(){
        try{
            int foodQTY = Integer.parseInt(editTextquantity.getText().toString());
            String foodPrice = "500";
            String foodName = "BBQ";
            if(String.valueOf(foodQTY).isEmpty() || foodQTY < 0) {
                Toast.makeText(this, "Enter Valid Quantity", Toast.LENGTH_SHORT).show();
            }
            else {
                int totalPrice = foodQTY * Integer.parseInt(foodPrice);
                boolean isItemAddedtoOrder = myDB.addItemtoOrder(foodName,foodPrice,String.valueOf(foodQTY), String.valueOf(totalPrice) );
                if(isItemAddedtoOrder) {
                    Toast.makeText(this, "Food Item Order Successfully", Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(this, "Food Item Not Added to Order", Toast.LENGTH_SHORT).show();
                }
            }
        }
        catch (Exception e) {
            Toast.makeText(this, e.getMessage().toString(), Toast.LENGTH_SHORT).show();
        }
    }
}