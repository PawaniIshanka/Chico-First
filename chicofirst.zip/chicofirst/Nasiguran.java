package com.example.chicofirst;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Nasiguran extends AppCompatActivity {
    DatabaseHelper myDB;
    EditText editTextquantity;
    TextView textFoodName,textPrice;
    Button btnOrder, btnFinalize;
    String foodName, price;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nasiguran);
        myDB = new DatabaseHelper(this);
        textFoodName = findViewById(R.id.textfoodNameNasiguran);
        textPrice = findViewById(R.id.textPriceNasiguran);
        editTextquantity = findViewById(R.id.editTextNasiguranQTY);
        btnOrder = findViewById(R.id.btnOrderNasiguran);
        btnFinalize = findViewById(R.id.btnCheckoutNasiguran);
        //Set information of food
        foodName = "Nasiguran";
        price = "RS.900/=";
        textFoodName.setText(foodName);
        textPrice.setText(price);
        final ImageView btnHome = (ImageView) findViewById(R.id.btnHome);
        final ImageView btnPay = (ImageView) findViewById(R.id.btnPay);
        final ImageView btnLocation = (ImageView) findViewById(R.id.btnLocation);
        btnHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
                Intent i = new Intent(getApplicationContext(), Menu.class);
                startActivity(i);
            }
        });
        btnPay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
                Intent i = new Intent(getApplicationContext(), Payment.class);
                startActivity(i);
            }
        });
        btnLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
                Intent i = new Intent(getApplicationContext(), MapsActivity.class);
                startActivity(i);
            }
        });
        final ImageView btnLeft = (ImageView) findViewById(R.id.btnleft);
        btnLeft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
                Intent i = new Intent(getApplicationContext(), SeaFood.class);
                startActivity(i);
            }
        });
        final ImageView btnRight = (ImageView) findViewById(R.id.btnRight);
        btnRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                finish();
                Intent i = new Intent(getApplicationContext(), Kottu.class);
                startActivity(i);
            }
        });
        btnOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addToCart();
            }
        });
        btnFinalize.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean isOrderTableEmpty = myDB.getRowCountOrders();
                if(isOrderTableEmpty) {
                    Toast.makeText(Nasiguran.this, "No Item in Cart. Please Add item before proceed to checkout", Toast.LENGTH_SHORT).show();
                } else {
                    finish();
                    Intent i = new Intent(getApplicationContext(), OrderDetails.class);
                    startActivity(i);
                }
            }
        });
    }
    public void addToCart(){
        try{
            int foodQTY = Integer.parseInt(editTextquantity.getText().toString());
            String foodPrice = "900";
            String foodName = "Nasiguran";
            if(String.valueOf(foodQTY).isEmpty() || foodQTY < 0) {
                Toast.makeText(this, "Enter Valid Quantity", Toast.LENGTH_SHORT).show();
            }
            else {
                int totalPrice = foodQTY * Integer.parseInt(foodPrice);
                boolean isItemAddedtoOrder = myDB.addItemtoOrder(foodName,foodPrice,String.valueOf(foodQTY), String.valueOf(totalPrice) );
                if(isItemAddedtoOrder) {
                    Toast.makeText(this, "Food Item Added to Order Successfully", Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(this, "Food Item Not Added to Order", Toast.LENGTH_SHORT).show();
                }
            }
        }
        catch (Exception e) {
            Toast.makeText(this, e.getMessage().toString(), Toast.LENGTH_SHORT).show();
        }
    }
}