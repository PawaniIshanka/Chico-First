package com.example.chicofirst;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Rice extends AppCompatActivity {
    DatabaseHelper myDB;
    EditText editTextquantity;
    TextView textFoodName,textPrice;
    Button btnOrder, btnFinalize;
    String foodName, price;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rice);
        myDB = new DatabaseHelper(this);
        textFoodName = findViewById(R.id.textfoodNameFriedRice);
        textPrice = findViewById(R.id.textPriceFriedRice);
        editTextquantity = findViewById(R.id.editTextFriedRiceQTY);
        btnOrder = findViewById(R.id.btnOrderFriedRice);
        btnFinalize = findViewById(R.id.btnCheckoutFriedRice);
        //Set information of food
        foodName = "Fried Rice";
        price = "RS.700/=";
        textFoodName.setText(foodName);
        textPrice.setText(price);
        final ImageView btnHome = (ImageView) findViewById(R.id.btnHome);
        final ImageView btnPay = (ImageView) findViewById(R.id.btnPay);
        final ImageView btnLocation = (ImageView) findViewById(R.id.btnLocation);
        btnHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
                Intent i = new Intent(getApplicationContext(), Menu.class);
                startActivity(i);
            }
        });
        btnPay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
                Intent i = new Intent(getApplicationContext(), Payment.class);
                startActivity(i);
            }
        });
        btnLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
                Intent i = new Intent(getApplicationContext(), MapsActivity.class);
                startActivity(i);
            }
        });
        final ImageView btnLeft = (ImageView) findViewById(R.id.btnleft);
        btnLeft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
                Intent i = new Intent(getApplicationContext(), MilkRice.class);
                startActivity(i);
            }
        });
        final ImageView btnRight = (ImageView) findViewById(R.id.btnRight);
        btnRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
                Intent i = new Intent(getApplicationContext(), Bbq.class);
                startActivity(i);
            }
        });
        btnOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addToCart();
            }
        });
        btnFinalize.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean isOrderTableEmpty = myDB.getRowCountOrders();
                if(isOrderTableEmpty) {
                    Toast.makeText(Rice.this, "No Item in Cart. Please Add item before proceed to checkout", Toast.LENGTH_SHORT).show();
                } else {
                    finish();
                    Intent i = new Intent(getApplicationContext(), OrderDetails.class);
                    startActivity(i);
                }
            }
        });
    }
    public void addToCart(){
        try{
            int foodQTY = Integer.parseInt(editTextquantity.getText().toString());
            String foodPrice = "700";
            String foodName = "Fried Rice";
            if(String.valueOf(foodQTY).isEmpty() || foodQTY < 0) {
                Toast.makeText(this, "Enter Valid Quantity", Toast.LENGTH_SHORT).show();
            }
            else {
                int totalPrice = foodQTY * Integer.parseInt(foodPrice);
                boolean isItemAddedtoOrder = myDB.addItemtoOrder(foodName,foodPrice,String.valueOf(foodQTY), String.valueOf(totalPrice) );
                if(isItemAddedtoOrder) {
                    Toast.makeText(this, "Food Item Added to Order Successfully", Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(this, "Food Item Not Added to Order", Toast.LENGTH_SHORT).show();
                }
            }
        }
        catch (Exception e) {
            Toast.makeText(this, e.getMessage().toString(), Toast.LENGTH_SHORT).show();
        }
    }
}