package com.example.chicofirst;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;
import java.util.List;

public class Menu extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        RecyclerView recyclerView = findViewById(R.id.recycleView);
        List<item> items = new ArrayList<item>();
        items.add(new item("BBQ" , "Rs.500.00" , R.drawable.bbq));
        items.add(new item("Sea Food" , "Rs.1000.00" , R.drawable.sea));
        items.add(new item("Nasiguran" , "Rs.900.00" , R.drawable.nasi));
        items.add(new item("Koththu" , "Rs.800.00" , R.drawable.kottu));
        items.add(new item("Milk Rice" , "Rs.400.00" , R.drawable.milkrice));
        items.add(new item("Fried Rice" , "Rs.700.00" , R.drawable.rice));
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new MyAdapter(getApplicationContext(),items));
        final Button btnView = (Button) findViewById(R.id.btnView);
        btnView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), Bbq.class);
                startActivity(i);
            }
        });
        final Button btnProfile = (Button) findViewById(R.id.btnProfile);
        btnProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), Profile.class);
                startActivity(i);
            }
        });
    }
}