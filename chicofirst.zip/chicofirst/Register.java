package com.example.chicofirst;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Register extends AppCompatActivity {
    DatabaseHelper myDB;
    EditText editName,editEmail,editPassword,editConfirmPassword;
    Button btnReg, btnLog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        myDB = new DatabaseHelper(this);
        editName = findViewById(R.id.editTextUserName);
        editEmail = findViewById(R.id.editTextEmailAddress);
        editPassword = findViewById(R.id.editTextPassword);
        editConfirmPassword = findViewById(R.id.editTextRePassword);
            btnReg =findViewById(R.id.btnReg);
            btnLog =findViewById(R.id.btnLog);
        btnLog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), Login.class);
                startActivity(i);
            }
        });
        registerUser();
    }
    public void registerUser() {
        btnReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    String userName = editName.getText().toString();
                    String email = editEmail.getText().toString();
                    String password = editPassword.getText().toString();
                    String confirmPassword = editConfirmPassword.getText().toString();
                    //Check inputs empty?
                    if (userName.isEmpty() || email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
                        Toast.makeText(getApplicationContext(), "All input fields are Required !", Toast.LENGTH_LONG).show();
                    } else {
                        boolean isUserNameExits = myDB.checkUsername(userName);
                        if (isUserNameExits == true) {
                            Toast.makeText(getApplicationContext(), "User name is already exits", Toast.LENGTH_LONG).show();
                        } else {
                            String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
                            boolean isEmailValid = false;
                            boolean isPasswordMatch = false;
                            if (password.equals(confirmPassword)) {
                                isPasswordMatch = true;
                            } else {
                                Toast.makeText(getApplicationContext(), "Password and Re-Password must be same", Toast.LENGTH_LONG).show();
                            }
                            if (email.matches(emailPattern))
                                isEmailValid = true;
                            else
                                Toast.makeText(getApplicationContext(), "Email is not in valid format", Toast.LENGTH_LONG).show();
                            if (isEmailValid && isPasswordMatch ) {
                                boolean isInserted = myDB.insertRegistrationData(userName, email, password);
                                if (isInserted == true) {
                                    Toast.makeText(getApplicationContext(), "Registration Successful", Toast.LENGTH_LONG).show();
                                    finish();
                                    Intent i = new Intent(getApplicationContext(), Login.class);
                                    startActivity(i);
                                } else
                                    Toast.makeText(getApplicationContext(), "Registration Unsuccessful", Toast.LENGTH_LONG).show();
                            }
                        }
                    }
                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), e.getMessage().toString(), Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}