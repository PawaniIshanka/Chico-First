package com.example.chicofirst;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class OrderDetails extends AppCompatActivity {
    DatabaseHelper myDB;
    TextView displayOrderDetails;
    Button btnOnline, btnCash, btnBack;
    int totalPrice;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_detail);
        btnOnline = findViewById(R.id.btnOnline);
        btnCash = findViewById(R.id.btnCash);
        btnBack = findViewById(R.id.btnBack);
        totalPrice = 0;
        myDB = new DatabaseHelper(this);
        displayOrderDetails = findViewById(R.id.textViewOderDetails);
        final Button btnOnline = (Button) findViewById(R.id.btnOnline);
        final ImageView btnProf = (ImageView) findViewById(R.id.btnProf);
        btnProf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
                Intent i = new Intent(getApplicationContext(), Profile.class);
                startActivity(i);
            }
        });
        btnOnline.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AppGlobal.TotalAmount = totalPrice;
                Intent i = new Intent(getApplicationContext(), Payment.class);
                startActivity(i);
            }
        });
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), Menu.class);
                startActivity(i);
            }
        });
        btnCash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
                cashPayment();
            }
        });
        showOrderDetails();
    }
    public void showOrderDetails() {
        Cursor results = myDB.checkoutOrder();
        StringBuffer buffer = new StringBuffer();
        while (results.moveToNext()) {
            buffer.append("Name : " + results.getString(1) + "\n");
            buffer.append("Amount : RS " + results.getString(2) + "/=\n");
            buffer.append("QTY  : " + results.getString(3) + "\n\n");
            totalPrice += Integer.parseInt(results.getString(4));
        }
        buffer.append("\n" + "Total Price : RS " + totalPrice +"/=" );
        displayOrderDetails.setText(buffer);
         AppGlobal.TotalAmount = totalPrice;
    }
    public void cashPayment() {
            boolean isAddressAvailable = myDB.checkAddress(AppGlobal.userName);
            if (isAddressAvailable) {
                Toast.makeText(this, "Thank you for your order! We have received it and will begin processing it shortly ", Toast.LENGTH_SHORT).show();
                finish();
                myDB.clearTableCurrentOrder();
                Intent i = new Intent(getApplicationContext(), Menu.class);
                startActivity(i);
            }
            else {
                Toast.makeText(this, "Your Address not Added yet. Please Add Address Before Make Order", Toast.LENGTH_SHORT).show();
                finish();
                Intent i = new Intent(getApplicationContext(), Profile.class);
                startActivity(i);
            }
        }
    }