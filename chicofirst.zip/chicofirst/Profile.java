package com.example.chicofirst;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.database.Cursor;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Profile extends AppCompatActivity {
    DatabaseHelper myDB;
    EditText editName, editAddress, editPhone;
    TextView viewEmail, viewUserName;
    Button btnSave, btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        String username = AppGlobal.userName;
        myDB = new DatabaseHelper(this);
        editName = findViewById(R.id.editTextPersonName);
        editAddress = findViewById(R.id.editTextAddress);
        editPhone = findViewById(R.id.editTextPhone);
        viewEmail = findViewById(R.id.textViewEmailAddress);
        viewUserName = findViewById(R.id.textViewUserName);
        btnSave = findViewById(R.id.btnSave);
        btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
                Intent i = new Intent(getApplicationContext(), Menu.class);
                startActivity(i);
            }
        });
        loadData(username);
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                updateUserData(username);
            }
        });
    }
    public void loadData(String username) {
        try {
            Cursor data = myDB.getUserData(username);
            Cursor personalData = myDB.getPersonalData(username);
            while (data.moveToNext()) {
                viewUserName.setText(data.getString(0));
                viewEmail.setText(data.getString(1));
            }
            if (personalData.getCount() == 0) {
                Toast.makeText(this, "No Data in Database. Please Add your Data", Toast.LENGTH_SHORT).show();
            } else {
                while (personalData.moveToNext()) {
                    editName.setText(personalData.getString(0));
                    editAddress.setText(personalData.getString(1));
                    editPhone.setText(personalData.getString(2));
                }
            }
        } catch (Exception e) {

            Toast.makeText(this, e.getMessage().toString(), Toast.LENGTH_SHORT).show();
        }
    }
    public void updateUserData(String username) {
        try {
            String name = editName.getText().toString();
            String address = editAddress.getText().toString();
            String telePhone = editPhone.getText().toString();
            if(name.isEmpty() || address.isEmpty() || telePhone.isEmpty() ){
                Toast.makeText(this, "All Fields are required !", Toast.LENGTH_SHORT).show();
            }
            else {
                boolean isDataAlreadyAvailable = myDB.checkAddress(AppGlobal.userName);
                if(isDataAlreadyAvailable) {
                    boolean isUpdatedSuccess = myDB.updateUserDetails(AppGlobal.userName,name,address,telePhone);
                    if(isUpdatedSuccess) {
                        Toast.makeText(this, "Data Updated Success", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Toast.makeText(this, "Data Updated Unsuccessful", Toast.LENGTH_SHORT).show();
                    }
                }
                else {
                    boolean isDataInserted = myDB.insertUserDetails(username, name, address, telePhone);
                    if(isDataInserted) {
                        Toast.makeText(this, "Data Saved Success", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Toast.makeText(this, "Data Saving Unsuccessful", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }
        catch (Exception e) {
            Toast.makeText(this, e.getMessage().toString(), Toast.LENGTH_SHORT).show();
        }
    }
}
