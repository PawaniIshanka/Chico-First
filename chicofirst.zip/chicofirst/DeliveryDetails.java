package com.example.chicofirst;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
public class DeliveryDetails extends AppCompatActivity {
    DatabaseHelper myDb;
    Button btnDelivery,btnBackDeli;
    ImageView locButton;
    ImageView weaButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delivery_details);
        locButton = findViewById(R.id.locationButton);
        weaButton = findViewById(R.id.weatherButton);
        btnDelivery = findViewById(R.id.btnDelivery);
        btnBackDeli = findViewById(R.id.btnBackDeli);
        locButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), Map.class);
                startActivity(i);
            }
        });

        weaButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), Weather.class);
                startActivity(i);
            }
        });
        btnDelivery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), OrderDetails.class);
                startActivity(i);
            }
        });
        btnBackDeli.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), Menu.class);
                startActivity(i);
            }
        });


    }
}
