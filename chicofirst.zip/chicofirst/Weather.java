package com.example.chicofirst;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.MediaPlayer;
import android.widget.TextView;
import android.widget.VideoView;

public class Weather extends AppCompatActivity implements SensorEventListener {
    private TextView textView;
    private SensorManager sensorManager;
    private Sensor tempSensor;
    private Boolean isTemperatureSensoreAvailable;
//    private Sensor pressure;
    private float changedValue;
//    MediaPlayer mediaPlayer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weather);
        VideoView video = findViewById(R.id.skyVideo);
        video.setVideoPath("android.resource://" + getPackageName() + "/" + R.raw.sky);
        video.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            public void onCompletion(MediaPlayer mp) {
                video.start();
                //need to make transition seamless.
            }
        });
        video.requestFocus();
        video.start();
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
//        pressure = sensorManager.getDefaultSensor(Sensor.TYPE_PRESSURE);
        textView = findViewById(R.id.InformationText);
        if (sensorManager.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE) != null) {
            tempSensor = sensorManager.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE);
            isTemperatureSensoreAvailable = true;
        } else {
            textView.setText("Temperature Sensor is not available");
            isTemperatureSensoreAvailable = false;
        }
    }
    @Override
    public final void onAccuracyChanged(Sensor sensor, int accuracy) {
    }
    @Override
    public final void onSensorChanged(SensorEvent event) {
        changedValue = event.values[0];
        textView.setText(changedValue + " °C");
    }
    @Override
    protected void onResume() {
        super.onResume();
        if (isTemperatureSensoreAvailable) {
            sensorManager.registerListener(this, tempSensor, SensorManager.SENSOR_DELAY_NORMAL);
        }
    }
    @Override
    protected void onPause() {
        super.onPause();
        if (isTemperatureSensoreAvailable) {
            sensorManager.unregisterListener(this);
        }
    }
}